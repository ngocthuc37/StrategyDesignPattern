namespace StrategyPattern
{
    public interface IPromoteStrategy
    {
        double DoDiscount(double price);
    }
}